function DoIt
  let First = document.getElementById("First").value;
  let Plural = document.getElementById(" Plural").value; 
  let Place = document.getElementById(" Place") .value;
  let Adjective = document.getElementById("Adjective").value;

  document.getElementById( " myForm") . innerHTML = " <h3> your name is <spanclass= 'First'>" + First + "" + Plural + " </span></h3><p> This concludes this mad lib.</p>"
  

